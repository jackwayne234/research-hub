# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

## Gitea (Local Git Server)

- URL: `http://gitea:3000`
- User: `chris`
- Git credentials are pre-configured — just clone with HTTP, e.g.:
  `git clone http://gitea:3000/chris/<repo-name>.git`
- API base: `http://gitea:3000/api/v1`
- API token: `04f51628de717fb9d1e26de1d458bf66cf050726`

### Known repos
- `chris/benford-fun` → GR/Benford metric work, blackhole & wormhole papers, 4D Schwarzschild-Benford equation, Euler/prime substrate drafts
- `chris/benford-physics` → Benford's Law physics papers, experiments, data, drafts
- `chris/Climate_Benford` → Benford Law analysis of climate & environmental datasets
- `chris/math` → Math study materials, calculator tools, algebra through trig practice
- `chris/nradix-chip-package` → N-Radix chip tapeout package: DRC rules, foundry submission, circuit simulation, layer mapping
- `chris/optical-computing-workspace` → N-Radix wavelength-division optical computer development
- `chris/outreach` → Content, YouTube scripts, social media, presentations
- `chris/war-room` → Session notes, bootstrap docs, project coordination
- `chris/disk-wipe-utility` → Disk wipe utility script
- `chris/telegram-cad-bot` → Telegram CAD bot

Add whatever helps you do your job. This is your cheat sheet.
